<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

goto_url(G5_SHOP_URL.'/item.php?it_id='.$it_id.'#sit_qa');
?>