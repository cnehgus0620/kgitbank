Theme Name: sample50
Theme URI: http://theme.sir.kr/yongcart53/demo/sample51
Maker: SIR
Maker URI: http://sir.kr
Version: 5.4.2.7.1
Detail: sample51 Theme
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html